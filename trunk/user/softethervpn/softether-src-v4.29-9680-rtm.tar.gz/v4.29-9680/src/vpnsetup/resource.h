//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by vpnsetup.rc
//
#define IDI_ICON1                       101
#define IDI_ICON2                       103
#define IDI_VPNSVR                      103
#define IDI_VPNSETUP                    103
#define IDI_SETUP_MAIN                  103
#define IDI_SETUP_INTERNET              104
#define IDI_SETUP_PROTOCOL              105
#define IDI_SETUP_SWITCH                106
#define IDI_ICON3                       107
#define IDI_SETUP_MACHINE               107
#define IDI_ICON4                       108
#define IDI_ICON5                       109
#define IDI_ICON6                       110
#define IDI_ICON7                       111
#define IDI_ICON8                       112
#define IDI_ICON9                       113
#define IDI_ICON10                      115
#define IDI_ICON11                      120

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        121
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
